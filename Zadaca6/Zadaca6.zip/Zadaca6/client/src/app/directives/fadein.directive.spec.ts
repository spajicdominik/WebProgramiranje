import { FadeinDirective } from './fadein.directive';

describe('FadeinDirective', () => {
  it('should create an instance', () => {
    const directive = new FadeinDirective();
    expect(directive).toBeTruthy();
  });
});
