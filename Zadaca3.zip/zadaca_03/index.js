const express = require('express');
const dataModule = require('./data');
const app = express();
const port = 5000;

app.use('/css', express.static(`${__dirname}\\client\\assets\\css`));
app.use('/js', express.static(`${__dirname}\\client\\assets\\scripts`));
app.use('/images', express.static(`${__dirname}\\client\\assets\\images`));

app.get('/', (req, res) => {

    res.sendFile(`${__dirname}\\client\\index.html`);
    
});

app.get('/data', (req, res) => {

    res.jsonp(dataModule.data);

});

app.listen(port, () => {

    console.log(`open on ${port}`);

});