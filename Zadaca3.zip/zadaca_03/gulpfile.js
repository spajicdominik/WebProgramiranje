const { src, dest, watch, series, parallel, task } = require("gulp");
const sass = require("sass");
const gulp_sass = require("gulp-sass")(sass);
const browser_sync = require("browser-sync");
const rename = require("gulp-rename");
const uglify = require("gulp-uglify");
const minifycss = require("gulp-minify-css");

const client_dir = "./client/";
const client_assets_dir = `${client_dir}assets/`;
const client_js_dir = `${client_assets_dir}scripts/`;
const client_css_dir = `${client_assets_dir}css/`;
const client_scss_dir = `${client_assets_dir}scss/`;

const js_dependencies = [
    "./node_modules/jquery/dist/jquery.min.js",
    "./node_modules/popper.js/dist/popper.min.js",
    "./node_modules/bootstrap/dist/js/bootstrap.bundle.min.js",
    "./node_modules/@fortawesome/fontawesome-free/js/all.min.js",
];

const css_dependencies = [
    "./node_modules/bootstrap/dist/css/bootstrap.min.css"
]


function js()
{
    return src(js_dependencies)
        .pipe(dest(client_js_dir));
}

function css()
{
    return src(css_dependencies)
        .pipe(dest(client_css_dir))
}

function scss2css()
{
    return src(client_scss_dir + "*.scss")
        .pipe(gulp_sass())
        .pipe(dest(client_css_dir));
}

exports.js = js;
exports.sass = scss2css;

exports.dependencies = parallel(js, css);

function reload_browser(cb)
{
    browser_sync.reload();
    cb();
}

function watch_and_refresh(cb) 
{
    browser_sync.init({ server: client_dir });
    
    watch(
        `${client_scss_dir}*.scss`, 
        { ignoreInitial: false, events: 'all'},
        series(scss2css, reload_browser)
    );
    
    watch(
        `${client_dir}index.html`, 
        { events: 'change' }, 
        reload_browser
    );
    
    cb();
}

function minify_css() {
    return src([`${client_css_dir}*.css`, `!${client_css_dir}*.min.css`])
        .pipe(minifycss( {processImport: false} ))
        .pipe(rename({ extname: ".min.css" }))
        .pipe(dest(client_css_dir));
}

function watch_and_minify_css() {
    return watch([`${client_css_dir}*.css`, `!${client_css_dir}*.min.css`], minify_css);
}

function minify_js() 
{
    return src([`${client_js_dir}*.js`, `!${client_js_dir}*.min.js`])
        .pipe(uglify())
        .pipe(rename({ extname: ".min.js" }))
        .pipe(dest(client_js_dir));
}

function watch_and_minify_js() {
    return watch([`${client_js_dir}*.js`, `!${client_js_dir}*.min.js`], minify_js);
}

br = series(js, css, scss2css, minify_css, minify_js);
task("br", br);

exports.default = series(js, css, watch_and_refresh, watch_and_minify_css, watch_and_minify_js);