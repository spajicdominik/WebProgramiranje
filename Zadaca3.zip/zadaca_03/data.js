exports.data = 
[
    {name: "audio.mp3", size: 1.71, categories: []},
    {name: "some_photo.png", size: 9.24, categories: ["pinned"]},
    {name: "seminar-report.docx", size: 2.53, categories: ["shared"]},
    {name: "manual.pdf", size: 1.82, categories: ["shared", "pinned"]},
    {name: "rezultati.xlsx", size: 6.71, categories: ["pinned"]},
    {name: "photo2.png", size: 1.57, categories: ["trash"]},
    {name: "norway.mp4", size: 5.84, categories: ["trash"]},
    {name: "yet_another.jpg", size: 8.04, categories: ["trash"]},
    {name: "speech.wav", size: 8.56, categories: ["trash"]}
];

