$(document).ready(function () {

    $("#file-container").hide();

    getData("files");

    $("#file-container").fadeIn("slow");

    $(".page-link").click(function (event) {

        destination = event.target.id.split("-")[1];

        getData(destination);

        $("#file-container").hide().fadeIn("slow");
    });

    $(".dropdown-item").click(function () {

        sortOrder = this.id.split("-")[1];
        
        $("#dropdownMenuLink").text(this.text);

        $("#file-container").fadeOut("slow", function() {

            changeFileOrder(sortOrder);

            $("#file-container").fadeIn();
        });
    });
});

function changePage(destination, data)
{
    $("#navbarToggler").removeClass("show");
    $("#dropdownMenuLink").text("Default");
    changePageTitle(destination);
    changeSelectedPage(destination);
    prepareFiles(destination, data, "");
}

function changePageTitle(destination)
{
    title = ""

    switch(destination)
    {
        case "files":
            title = "Here you can find all your <b>files</b>";
            break;
        case "shared":
            title = "Items you've <b>shared</b> with someone";
            break;
        case "pinned":
            title = "You can easily access <b>pinned</b> items";
            break;
        case "trash":
            title = "Items in <b>trash</b> will be removed after 15 days";
            break;
    }

    $("#page-title").html(title);
}

function changeSelectedPage(destination)
{
    $("#link-files").removeClass("active");
    $("#link-shared").removeClass("active");
    $("#link-pinned").removeClass("active");
    $("#link-trash").removeClass("active");

    switch(destination)
    {
        case "files":
            $("#link-files").addClass("active");
            break;
        case "shared":
            $("#link-shared").addClass("active");
            break;
        case "pinned":
            $("#link-pinned").addClass("active");
            break;
        case "trash":
            $("#link-trash").addClass("active");
            break;
    }
}

function makeFile(file)
{
    fileId = "fileid_" + file.name;

    fileHTML = `<div class="col-sm-6 col-md-6 col-lg-4 p-3">
                    <div id="${fileId}" class="file card">
                        <div class="card-body">
                        <h5 class="card-title">${file.name}</h5>
                        <h6 class="card-subtitle mb-2 text-muted">${file.size} mb</h6>
                        <p class="card-text file-text">${getFileIcon(file.name)}</p>
                            <div class="file-link-container d-inline-flex">
                                <a class="card-link file-card-link" href="#"><i class="fa fa-download"></i></a>
                                <a class="card-link file-card-link" href="#"><i class="fa fa-share"></i></a>
                                <a class="card-link file-card-link" href="#"><i class="fa fa-trash"></i></a>
                            </div>
                        </div>
                    </div>
                </div>`

    $("#file-container").append(fileHTML);

}

function makeFiles()
{
    filesToAdd.forEach(function (file) {
        makeFile(file);
    });
}

function getFileIcon(fileName)
{
    result = "";
    extension = fileName.split('.').pop().toLowerCase();

    switch(extension)
    {
        case "mp3":
        case "wav":
            result = "🎵";
            break;
        case "jpg":
        case "png":
            result = "📷";
            break;
        case "docx":
            result = "📘";
            break;
        case "pdf":
            result = "📕";
            break;
        case "xlsx": 
            result = "📊";
            break;
        case "mp4":
            result = "🎥";
            break;
        default:
            result = "🗋"
            break;
    }

    return result;
}

function prepareFiles(destination, data, sortOrder)
{
    filesDefaultSorted = []

    data.forEach(function (file) {
        if (shouldMake(file, destination))
        {
            filesDefaultSorted.push(file);
        }
    });

    changeFileOrder(sortOrder);
}

function changeFileOrder(sortOrder)
{
    filesToAdd = []

    filesDefaultSorted.forEach(function (file) {
        filesToAdd.push(file)
    });

    $("#file-container").empty();

    switch(sortOrder)
    {
        case "NameAtoZ":
            filesToAdd.sort((a, b) => (a.name > b.name) ? 1 : -1);
            break;
        case "NameZtoA":
            filesToAdd.sort((a, b) => (a.name < b.name) ? 1 : -1);
            break;
    }

    makeFiles();
}

function shouldMake(file, destination)
{
    if (destination == "trash")
    {
        return file.categories.includes("trash");
    }
    else if (destination == "files")
    {
        return !file.categories.includes("trash");
    }
    else
    {
        return file.categories.includes(destination);
    }
}
