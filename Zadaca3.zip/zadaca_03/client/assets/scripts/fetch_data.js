function getData(destination) {

    $.get("/data", (data) => {

        changePage(destination, data);
        
    });

}